import sys
import networkx as nx
import numpy as np
from multiprocessing import Pool
import time
import os.path
import subprocess

a_id = {}
i_id = {}
atom_map = {}
rev_atom_map = {}
atom_count = 0

active_file = sys.argv[2]
inactive_file = sys.argv[3]
infile = sys.argv[1]
test_file = sys.argv[4]

a_subgraph_list = []
i_subgraph_list = []


feat_vec = []
test_feat_vec = []
no_of_pools = 6


def active_read(activefile):
    for line in open(activefile): a_id[int(line.rstrip('\n'))] = 1


def inactive_read(inactivefile):
    for line in open(inactivefile): i_id[int(line.rstrip('\n'))] = -1


def fill_map(in_loc):
    lines = [line.rstrip('\n') for line in open(in_loc)]

    line_no = 0
    global atom_count
    global atom_map

    while line_no < len(lines):
        if lines[line_no][0] == "#":
            line_no += 1

            no_of_vertex = int(lines[line_no])
            for vertex_no in range(no_of_vertex):
                line_no += 1
                atom = lines[line_no]
                if atom not in atom_map:
                    atom_map[atom] = atom_count
                    rev_atom_map[atom_count] = atom
                    atom_count += 1

            line_no += 1
            no_of_edge = int(lines[line_no])
            for edge_no in range(no_of_edge):
                line_no += 1
                edge = lines[line_no]
            line_no += 1
        else:
            line_no += 1
    print("Atom Map Filled ")


def split_file(in_loc, out_loc, type_dict):
    lines = [line.rstrip('\n') for line in open(in_loc)]
    outfile = open(out_loc, "w")

    line_no = 0
    graph_no = 0
    global atom_count
    global atom_map

    while line_no < len(lines):
        if lines[line_no][0] == "#" and int(lines[line_no][1:]) in type_dict:
            outfile.write("t # " + str(graph_no) + "\n")
            graph_no += 1
            line_no += 1

            no_of_vertex = int(lines[line_no])
            for vertex_no in range(no_of_vertex):
                line_no += 1
                atom = lines[line_no]
                outfile.write("v " + str(vertex_no) + " " + str(atom_map[atom]) + "\n")

            line_no += 1
            no_of_edge = int(lines[line_no])
            for edge_no in range(no_of_edge):
                line_no += 1
                edge = lines[line_no]
                outfile.write("e " + edge + "\n")
            line_no += 1
        else:
            line_no += 1
    print("Splitted Input file to ", out_loc)
    return graph_no


def train_file_make_to_test(in_loc, outfile, type_dict):
    lines = [line.rstrip('\n') for line in open(in_loc)]

    global atom_map
    flag = 0
    for line in lines:
        if line[0] == "#" and int(line[1:]) in type_dict:
            flag = True
        elif line[0] == "#" and int(line[1:]) not in type_dict:
            flag = False
            continue
        if flag:
            outfile.write(line + "\n")


def a_then_i_train():
    outfile = open("train15.txt", "w")
    train_file_make_to_test(infile, outfile, a_id)
    outfile = open("train15.txt", "a")
    train_file_make_to_test(infile, outfile, i_id)


def call_gspan(a_minsup=0.2,i_minsup=0.1 ):
    cmd_a="./GSPAN/gSpan -f ./GSPAN/input_gspan_active.txt -s "+str(a_minsup)+" -o -i"
    cmd_i="./GSPAN/gSpan -f ./GSPAN/input_gspan_inactive.txt -s "+str(i_minsup)+" -o -i"
    subprocess.call(cmd_a.split(" "))
    subprocess.call(cmd_i.split(" "))


def freqsub_to_graph(in_loc, subgraph_list, threshold):
    lines = [line.rstrip('\n') for line in open(in_loc)]

    line_no = 0
    while line_no < len(lines):
        if lines[line_no][0] == "t":
            G = nx.Graph(ID=lines[line_no])
            # print("Processed trans no: ",lines[line_no])
            line_no += 1

        vertex_cnt = 0
        while lines[line_no][0] == "v":
            vertex_cnt += 1
            # print(lines[line_no])
            vertex_no, atom_id = [int(i) for i in lines[line_no][2:].split(" ")]
            G.add_node(vertex_no, Atom=rev_atom_map[atom_id])
            line_no += 1

        if vertex_cnt == 1:
            G.clear();line_no += 2;continue
        elif vertex_cnt == 2:
            G.clear();line_no += 3;continue
        else:
            while lines[line_no][0] == "e":
                u, v, bond_type = [int(i) for i in lines[line_no][2:].split(" ")]
                # print(lines[line_no],u,v,bond_type)
                G.add_edge(u, v, bond=bond_type)
                line_no += 1
            g_count = int((G.graph['ID'][2:].split(" "))[3])
            # print(G.graph['ID'][2:].split(" "))
            if g_count > threshold[0] and g_count < threshold[1]:
                subgraph_list.append(G)
            else:
                G.clear()

            if lines[line_no][0] == "x":
                # print(lines[line_no])
                line_no += 2
        # print("Frequent subgraph stored as Graph for : ", in_loc)


def subgraph_to_file(Graph, subgraph_loc):
    outfile = open(subgraph_loc, "w")
    g_id = "".join(Graph.graph['ID'][2:].split(" "))
    outfile.write(g_id + "\n")

    outfile.write(str(len(Graph)) + "\n")
    for node in Graph.nodes(data=True): outfile.write(node[1]['Atom'] + "\n")

    outfile.write(str(len(Graph.edges)) + "\n")
    for edge in Graph.edges(data=True):
        text = str(edge[0]) + " " + str(edge[1]) + " " + str(edge[2]['bond'])
        outfile.write(text + "\n")


def write_to_file(lines, file_loc):
    outfile = open(file_loc, "w")
    for line in lines:
        for element in line:
            outfile.write(str(int(element)) + " ")
        outfile.write("\n")
    outfile.close()
    print("Successfull write complete of ", file_loc)


def fill_pool(Graph, i, ):
    p_id = str(i % no_of_pools)
    t_id = str(i)
    subgraph_loc = "subgraph" + t_id + ".txt"
    subgraph_to_file(Graph, "Subgraphs/" + subgraph_loc)

    result_loc = "result" + t_id + ".txt"
    result_file = "Results/" + result_loc
    cmd_ri = "./ri36 mono geu ./train15.txt ./Subgraphs/" + subgraph_loc + " ./Results/" + result_loc

    status = subprocess.call(cmd_ri.split(" "))
    #print("Executed: ", i)
    while 1:
        if os.path.isfile(result_file):
            # res_file=open(result_file,'w+')
            # if os.fstat(res_file.fileno()).st_size:
            lines = np.transpose(np.loadtxt(result_file));
            break
        else:
            print("Waiting: ", i);time.sleep(1)
    return lines


def make_train_feat_vec():
    global feat_vec
    pool = Pool(no_of_pools)
    feat_a = (pool.starmap(fill_pool, [(a_subgraph_list[i], i) for i in range(len(a_subgraph_list))]))
    # feat_a=(pool.starmap(fill_pool, [(a_subgraph_list[i],i) for i in range(10)]))
    pool.close()
    pool.join()

    pool = Pool(no_of_pools)
    feat_i = (pool.starmap(fill_pool, [(i_subgraph_list[i], i) for i in range(len(i_subgraph_list))]))
    # feat_i=(pool.starmap(fill_pool, [(i_subgraph_list[i],i) for i in range(10)]))
    pool.close()
    pool.join()
    feat_vec = feat_a + feat_i


def write_to_file_train_test(lines, file_loc, type):
    outfile = open(file_loc, "w")
    if type:
        for line in lines:
            outfile.write(str(int(line[0])) + " ")
            for k in range(1, len(line)):
                outfile.write(str(k-1) + ":" + str(int(line[k])) + " ")
            outfile.write("\n")
        outfile.close()
    else:
        for line in lines:
            for k in range(len(line)):
                outfile.write(str(k) + ":" + str(int(line[k])) + " ")
            outfile.write("\n")
        outfile.close()
    print("Successfull write complete of ", file_loc)


def fill_pool_test(Graph, i, ):
    p_id = str(i % no_of_pools)
    t_id = str(i)
    subgraph_loc = "subgraph" + t_id + ".txt"
    subgraph_to_file(Graph, "SubgraphsTest/" + subgraph_loc)

    result_loc = "result" + t_id + ".txt"
    cmd_ri = "./ri36 mono geu " + test_file + " ./SubgraphsTest/" + subgraph_loc + " ./ResultsTest/" + result_loc

    status = subprocess.call(cmd_ri.split(" "))
    #print("Executed: ", i)
    while 1:
        if os.path.isfile("ResultsTest/" + result_loc):
            lines = np.transpose(np.loadtxt("ResultsTest/" + result_loc));
            break
        else:
            print("Waiting: ", i);time.sleep(1)
    return lines


def make_test_feat_vec():
    global test_feat_vec
    pool = Pool(no_of_pools)
    feat_a = (pool.starmap(fill_pool_test, [(a_subgraph_list[i], i) for i in range(len(a_subgraph_list))]))
    # feat_a=(pool.starmap(fill_pool, [(a_subgraph_list[i],i) for i in range(10)]))
    pool.close()
    pool.join()

    pool = Pool(no_of_pools)
    feat_i = (pool.starmap(fill_pool_test, [(i_subgraph_list[i], i) for i in range(len(i_subgraph_list))]))
    # feat_i=(pool.starmap(fill_pool, [(i_subgraph_list[i],i) for i in range(10)]))
    pool.close()
    pool.join()
    test_feat_vec = feat_a + feat_i

    write_to_file(test_feat_vec, "test15.txt")
    test_feat_vec = np.loadtxt("test15.txt")
    test_xx = np.transpose(test_feat_vec)
    write_to_file_train_test(test_xx, "test.txt", 0)


def find_discr_feat():
    global a_subgraph_list
    global i_subgraph_list
    th_active = [0.20 * a_count, 1 * a_count]
    print("Initial active threshold : ", int(th_active[0]), int(th_active[1]))
    freqsub_to_graph("./GSPAN/input_gspan_active.txt.fp", a_subgraph_list, th_active)
    th_inactive = [0.10 * i_count, 1 * i_count]
    print("Initial inactive threshold: ", int(th_inactive[0]), int(th_inactive[1]))
    freqsub_to_graph("./GSPAN/input_gspan_inactive.txt.fp", i_subgraph_list, th_inactive)

    if len(a_subgraph_list) > 1200:
        loop = 0.2
        a_subgraph_list.clear()
        print('*********************************')
        while loop <= 0.4:
            a_subgraph_list.clear()
            th_active = [(loop) * a_count, (loop + 0.05) * a_count]
            # print("Threshold for active maxsup :", loop, " is: ", int(th_active[0]), int(th_active[1]))
            freqsub_to_graph("./GSPAN/input_gspan_active.txt.fp", a_subgraph_list, th_active)
            if len(a_subgraph_list) < 1200:
                print("Length Active is: ", len(a_subgraph_list), "for minsup ", loop)
                print('*********************************\n')
                break
            loop += 0.01

    if len(i_subgraph_list) > 700:
        loop = 0.1
        i_subgraph_list.clear()
        print('*********************************')
        while loop < 0.5:
            i_subgraph_list.clear()
            th_inactive = [(loop) * i_count, (loop + 0.15) * i_count]
            # print("Threshold for inactive maxsup :", loop, " is: ", int(th_inactive[0]), int(th_inactive[1]))
            freqsub_to_graph("./GSPAN/input_gspan_inactive.txt.fp", i_subgraph_list, th_inactive)
            if len(i_subgraph_list) < 700:
                print("Length Inctive is: ", len(i_subgraph_list), "for minsup ", loop)
                print('*********************************\n')
                break
            loop += 0.01


active_read(active_file)
inactive_read(inactive_file)
t_count=fill_map(infile)

a_count=split_file(infile, "GSPAN/input_gspan_active.txt" , a_id)
i_count=split_file(infile, "GSPAN/input_gspan_inactive.txt" ,i_id)
# print(a_count,i_count)

a_then_i_train()
call_gspan(0.2,0.1)

find_discr_feat()
# print("Final feature length is: ", len(a_subgraph_list), len(i_subgraph_list))


make_train_feat_vec()
write_to_file(feat_vec, "feature15.txt")


feat_vec=np.genfromtxt("feature15.txt")

total_train_len= a_count+i_count
Y=np.ones([1,total_train_len])
for i in range(a_count,total_train_len):Y[0,i]=-1
train_x=np.transpose(np.append(Y, feat_vec, axis=0))

write_to_file_train_test(train_x,"train.txt", 1)

make_test_feat_vec()



# train_xx=train_x[100:800,1:]
# print(train_xx.shape)
# train_y=Y[0,100:800]
# print(train_y.shape)

# test_t=train_xx[:100, :]
# test_t=np.append(test_t, train_x[7500:7600,1:], axis=0)

# print(test_t.shape)
# orig_label=Y[0,:100]
# orig_label=np.append(orig_label, Y[0,7500:7600])

# from sklearn.svm import SVC
# clf = SVC(C=1, kernel='linear')
# clf.fit(train_xx,train_y)

# res=clf.predict(test_t)
# from sklearn.metrics import f1_score
# print(f1_score(orig_label,res,average='macro'))


