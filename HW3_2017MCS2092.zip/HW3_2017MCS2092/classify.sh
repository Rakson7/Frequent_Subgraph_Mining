#!/bin/sh

python3 compound_classification.py $1 $2 $3 $4
