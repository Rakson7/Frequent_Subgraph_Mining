import matplotlib.pyplot as plt
fsg_time = [140.4, 72.6, 29.7, 10.6, 0.6]
gspan_time = [138.9, 69.5, 27.54, 12.34, 4.93]
gaston_time = [10.25, 5.83, 2.59, 1.34, 0.46]
thresh = [5, 10, 25, 50, 95]

plt.plot(thresh, gspan_time, 'r--',marker='+', label='gSpan')
plt.plot(thresh, fsg_time, 'g--', marker='*', label='FSG' )
plt.plot(thresh, gaston_time, 'b--', marker='.', label='Gaston' )
plt.ylabel('Time (in sec)')
plt.xlabel('MinSup (in %)')
plt.title('gSpan Vs FSG Vs Gaston')
plt.legend()
plt.show()
